﻿using LiveScore.Models;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Data;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace LiveScore.Controllers
{
    public class FootballPlayerBController : ApiController
    {
        public HttpResponseMessage Get()
        {
            DataTable table = new DataTable();
            string query = @"
                           select * from dbo.fteamB
                           ";
            using (var con = new SqlConnection(ConfigurationManager.ConnectionStrings["cricket"].ConnectionString))
            using (var cmd = new SqlCommand(query, con))
            using (var da = new SqlDataAdapter(cmd))
            {
                cmd.CommandType = CommandType.Text;
                da.Fill(table);
            }
            return Request.CreateResponse(HttpStatusCode.OK, table);
        }
        public string put(FootballPlayerB fbl)
        {
            try
            {
                DataTable table = new DataTable();
                string query = @"
                           update dbo.fteamB set
                            player1='" + fbl.Player1 + @"'  
                            ,player2='" + fbl.Player2 + @"'
                            ,player3='" + fbl.player3 + @"'
                            ,player4='" + fbl.Player4 + @"'
                            ,player5='" + fbl.player5 + @"'
                            ,player6='" + fbl.player6 + @"'
                            ,player7='" + fbl.player7 + @"'
                            ,player8='" + fbl.player8 + @"'
                            ,player9='" + fbl.player9 + @"'
                            ,player10='" + fbl.Player10 + @"'
                            ,player11='" + fbl.player11 + @"'
                            ,player12='" + fbl.player12 + @"'
                            ,player13='" + fbl.player13 + @"'
                            ,player14='" + fbl.player14 + @"'
                             ";
                using (var con = new SqlConnection(ConfigurationManager.ConnectionStrings["cricket"].ConnectionString))
                using (var cmd = new SqlCommand(query, con))
                using (var da = new SqlDataAdapter(cmd))
                {
                    cmd.CommandType = CommandType.Text;
                    da.Fill(table);
                }


                return "Added Successfully";
            }
            catch (Exception)
            {
                return "Failed to add";

            }
        }
    }
}
