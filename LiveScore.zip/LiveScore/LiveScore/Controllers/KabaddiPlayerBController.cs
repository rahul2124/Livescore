﻿using LiveScore.Models;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Data;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace LiveScore.Controllers
{
    public class KabaddiPlayerBController : ApiController
    {
        public HttpResponseMessage Get()
        {
            DataTable table = new DataTable();
            string query = @"
                           select * from dbo.kteamB
                           ";
            using (var con = new SqlConnection(ConfigurationManager.ConnectionStrings["cricket"].ConnectionString))
            using (var cmd = new SqlCommand(query, con))
            using (var da = new SqlDataAdapter(cmd))
            {
                cmd.CommandType = CommandType.Text;
                da.Fill(table);
            }
            return Request.CreateResponse(HttpStatusCode.OK, table);
        }
        public string put(KabaddiPlayerB kbi)
        {
            try
            {
                DataTable table = new DataTable();
                string query = @"
                           update dbo.kteamB set
                            player1='" + kbi.Player1 + @"'  
                            ,player2='" + kbi.Player2 + @"'
                            ,player3='" + kbi.player3 + @"'
                            ,player4='" + kbi.Player4 + @"'
                            ,player5='" + kbi.player5 + @"'
                            ,player6='" + kbi.player6 + @"'
                            ,player7='" + kbi.player7 + @"'
                            ,player8='" + kbi.player8 + @"'
                            ,player9='" + kbi.player9 + @"'
                            ,player10='" + kbi.Player10 + @"'
                             where ID = " + kbi.Id + @"
                             ";
                using (var con = new SqlConnection(ConfigurationManager.ConnectionStrings["cricket"].ConnectionString))
                using (var cmd = new SqlCommand(query, con))
                using (var da = new SqlDataAdapter(cmd))
                {
                    cmd.CommandType = CommandType.Text;
                    da.Fill(table);
                }


                return "Added Successfully";
            }
            catch (Exception)
            {
                return "Failed to add";

            }
        }
    }
}
