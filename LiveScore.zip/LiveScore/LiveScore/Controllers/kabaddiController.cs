﻿using LiveScore.Models;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Data;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace LiveScore.Controllers
{
    public class kabaddiController : ApiController
    {
        public String errorMessage = "";
        public HttpResponseMessage Get()
        {
            DataTable table = new DataTable();
            string query = @"
                           select * from dbo.kabaadilive
                           ";
            using (var con = new SqlConnection(ConfigurationManager.ConnectionStrings["cricket"].ConnectionString))
            using (var cmd = new SqlCommand(query, con))
            using (var da = new SqlDataAdapter(cmd))
            {
                cmd.CommandType = CommandType.Text;
                da.Fill(table);
            }
            return Request.CreateResponse(HttpStatusCode.OK, table);
        }

        public string Put(Kabaddi kbi)
        {
            try
            {
                DataTable table = new DataTable();
                string query = @"
                           update dbo.kabaadilive set
                            category='" + kbi.category + @"'  
                            ,league='" +kbi.league + @"'
                            ,teamA='" + kbi.teamA + @"'
                            ,teamB='" + kbi.teamB + @"'
                            ,imageA='" + kbi.imageA + @"'
                            ,imageB='" + kbi.imageB + @"'
                            ,scoreA='" + kbi.scoreA + @"'
                            ,scoreB='" + kbi.scoreB + @"'
                             ";
                using (var con = new SqlConnection(ConfigurationManager.ConnectionStrings["cricket"].ConnectionString))
                using (var cmd = new SqlCommand(query, con))
                using (var da = new SqlDataAdapter(cmd))
                {
                    cmd.CommandType = CommandType.Text;
                    da.Fill(table);
                }


                return "Added Successfully";
            }
            catch (Exception)
            {
                return "Failed to add";

            }
        }
    }
}
