﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using System.Data; 
using System.Data.SqlClient;
using System.Configuration;
using LiveScore.Models;

namespace LiveScore.Controllers
{
    public class CricketController : ApiController
    {

        
        public String errorMessage = "";
        public HttpResponseMessage Get()
        {
            DataTable table = new DataTable();
            string query = @"
                           select * from dbo.cricketlive
                           ";
            using (var con = new SqlConnection(ConfigurationManager.ConnectionStrings["cricket"].ConnectionString))
            using (var cmd = new SqlCommand(query, con))
            using (var da = new SqlDataAdapter(cmd))
            {
                cmd.CommandType = CommandType.Text;
                da.Fill(table);
            }
            return Request.CreateResponse(HttpStatusCode.OK, table);
        }
     
        public string Put(Cricket cri)
        {
            try
            {
                DataTable table = new DataTable();
                string query = @"
                           update dbo.cricketlive set
                            category='" + cri.category + @"'  
                            ,league='" + cri.league + @"'
                            ,teamA='" + cri.teamA + @"'
                            ,teamB='" + cri.teamB + @"'
                            ,overA='" + cri.overA + @"'
                            ,overB='" + cri.overB + @"'
                            ,wicketA='" + cri.wicketA + @"'
                            ,wicketB='" + cri.wicketB + @"'
                            ,imageA='" + cri.imageA + @"'
                            ,imageB='" + cri.imageB + @"'
                            ,scoreA='"+cri.scoreA + @"'
                            ,scoreB='"+cri.scoreB + @"'
                             ";
                using (var con = new SqlConnection(ConfigurationManager.ConnectionStrings["cricket"].ConnectionString))
                using (var cmd = new SqlCommand(query, con))
                using (var da = new SqlDataAdapter(cmd))
                {
                    cmd.CommandType = CommandType.Text;
                    da.Fill(table);
                }


                return "Added Successfully";
            }
            catch (Exception)
            {
                return "Failed to add";

            }
        }
    }
}
