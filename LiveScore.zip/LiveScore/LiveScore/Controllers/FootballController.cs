﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Data;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using LiveScore.Models;

namespace LiveScore.Controllers
{
    public class FootballController : ApiController
    {
        public String errorMessage = "";
        public HttpResponseMessage Get()
        {
            DataTable table = new DataTable();
            string query = @"
                           select * from dbo.footballlive
                           ";
            using (var con = new SqlConnection(ConfigurationManager.ConnectionStrings["cricket"].ConnectionString))
            using (var cmd = new SqlCommand(query, con))
            using (var da = new SqlDataAdapter(cmd))
            {
                cmd.CommandType = CommandType.Text;
                da.Fill(table);
            }
            return Request.CreateResponse(HttpStatusCode.OK, table);
        }

            public string Put( Football fbl)
            {
                try
                {
                    DataTable table = new DataTable();
                    string query = @"
                           update dbo.footballlive set
                            category='" + fbl.category + @"'  
                            ,league='" + fbl.league + @"'
                            ,teamA='" + fbl.teamA + @"'
                            ,teamB='" +fbl.teamB + @"'
                            ,imageA='" + fbl.imageA + @"'
                            ,imageB='" +fbl.imageB + @"'
                            ,scoreA='" +fbl.scoreA + @"'
                            ,scoreB='" + fbl.scoreB + @"'
                             ";
                    using (var con = new SqlConnection(ConfigurationManager.ConnectionStrings["cricket"].ConnectionString))
                    using (var cmd = new SqlCommand(query, con))
                    using (var da = new SqlDataAdapter(cmd))
                    {
                        cmd.CommandType = CommandType.Text;
                        da.Fill(table);
                    }


                    return "Added Successfully";
                }
                catch (Exception)
                {
                    return "Failed to add";

                }
            }
    }
}
