﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Data;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using LiveScore.Models;

namespace LiveScore.Controllers
{
    public class CricketPlayerController : ApiController
    {
        public HttpResponseMessage Get()
        {
            DataTable table = new DataTable();
            string query = @"
                           select * from dbo.teamA
                           ";
            using (var con = new SqlConnection(ConfigurationManager.ConnectionStrings["cricket"].ConnectionString))
            using (var cmd = new SqlCommand(query, con))
            using (var da = new SqlDataAdapter(cmd))
            {
                cmd.CommandType = CommandType.Text;
                da.Fill(table);
            }
            return Request.CreateResponse(HttpStatusCode.OK, table);
        }
        public string put(CricketPlayer cri)
        {
            try
            {
                DataTable table = new DataTable();
                string query = @"
                           update dbo.teamA set
                            player1='" +  cri.Player1 + @"'  
                            ,player2='" + cri.Player2+ @"'
                            ,player3='" + cri.player3 + @"'
                            ,player4='" + cri.Player4 + @"'
                            ,player5='" + cri.player5 + @"'
                            ,player6='" + cri.player6 + @"'
                            ,player7='" + cri.player7 + @"'
                            ,player8='" + cri.player8 + @"'
                            ,player9='" + cri.player9 + @"'
                            ,player10='" + cri.Player10 + @"'
                            ,player11='" + cri.player11 + @"'
                            ,player12='" +cri.player12 + @"'
                            ,player13='"+cri.player13 +@"'
                            ,player14='"+cri.player14+@"'
                             ";
                using (var con = new SqlConnection(ConfigurationManager.ConnectionStrings["cricket"].ConnectionString))
                using (var cmd = new SqlCommand(query, con))
                using (var da = new SqlDataAdapter(cmd))
                {
                    cmd.CommandType = CommandType.Text;
                    da.Fill(table);
                }


                return "Added Successfully";
            }
            catch (Exception )
            {
                return "Failed to add";

            }


        }
    }
}
