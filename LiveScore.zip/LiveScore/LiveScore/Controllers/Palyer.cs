﻿namespace LiveScore.Controllers
{
    public class Palyer
    {
    }
}