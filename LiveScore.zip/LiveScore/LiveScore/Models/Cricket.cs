﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace LiveScore.Models
{
    public class Cricket
    {
        public long id { get; set; }
        public string category { get; set; }
        public string league { get; set; }
        public string teamA { get; set; }
        public string teamB { get; set; }
        public string wicketA { get; set; }
        public string wicketB { get; set; }
        public string overA { get; set; }
        public string overB { get; set; }   
        public string imageA { get; set; }
        public string imageB { get; set; }
        public string matchstatus { get; set; }
        public string scoreA { get; set; }
        public string scoreB { get; set; }
    }
    
}