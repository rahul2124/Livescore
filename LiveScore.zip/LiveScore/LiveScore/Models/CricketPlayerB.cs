﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace LiveScore.Models
{
    public class CricketPlayerB
    { 
            public long Id { get; set; }
            public string Player1 { get; set; }
            public string Player2 { get; set; }
            public string player3 { get; set; }
            public string Player4 { get; set; }
            public string player5 { get; set; }
            public string player6 { get; set; }
            public string player7 { get; set; }
            public string player8 { get; set; }
            public string player9 { get; set; }
            public string Player10 { get; set; }
            public string player11 { get; set; }
            public string player12 { get; set; }
            public string player13 { get; set; }
            public string player14 { get; set; }
        }
    }
