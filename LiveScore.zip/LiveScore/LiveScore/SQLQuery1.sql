select * from dbo.cricketlive;
alter table dbo.cricketlive add matchstatus varchar(1000);
insert into dbo.cricketlive values (1,'SRH','RCB','9','7','T20','IPL','5','6','https://en.wikipedia.org/wiki/Chennai_Super_Kings#/media/File:Chennai_Super_Kings_Logo.svg',
'https://en.wikipedia.org/wiki/Mumbai_Indians#/media/File:Mumbai_Indians_Logo.svg','live');